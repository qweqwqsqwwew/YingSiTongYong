//
//  HJG_YinSi.h
//  YingSiTongYong
//
//  Created by developer on 2018/10/8.
//  Copyright © 2018 developer. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HJG_YinSi : NSObject

@end

NS_ASSUME_NONNULL_END
